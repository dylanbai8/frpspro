#! /bin/bash
PS4='Line ${LINENO}: '
PATH=/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin:~/bin
export PATH
#===============================================================================================
#   System Required:  CentOS Debian or Ubuntu (32bit/64bit)
#   Description:  A tool to auto-compile & install frps on Linux
#   Author: Clang
#   Intro:  http://koolshare.cn/forum-72-1.html:
#===============================================================================================
program_name="frps"
version="1.8.5"
str_program_dir="/usr/local/${program_name}"
program_init="/etc/init.d/${program_name}"
program_config_file="frps.ini"
ver_file="/tmp/.frp_ver.sh"
get_char(){
    SAVEDSTTY=`stty -g`
    stty -echo
    stty cbreak
    dd if=/dev/tty bs=1 count=1 2> /dev/null
    stty -raw
    stty echo
    stty $SAVEDSTTY
}
# Check OS
checkos(){
    if grep -Eqi "CentOS" /etc/issue || grep -Eq "CentOS" /etc/*-release; then
        OS=CentOS
    elif grep -Eqi "Debian" /etc/issue || grep -Eq "Debian" /etc/*-release; then
        OS=Debian
    elif grep -Eqi "Ubuntu" /etc/issue || grep -Eq "Ubuntu" /etc/*-release; then
        OS=Ubuntu
    else
        echo "安装失败：Not support OS, Please reinstall OS and retry!"
        exit 1
    fi
}
fun_randstr(){
    strNum=$1
    [ -z "${strNum}" ] && strNum="16"
    strRandomPass=""
    strRandomPass=`tr -cd '[:alnum:]' < /dev/urandom | fold -w ${strNum} | head -n1`
    echo ${strRandomPass}
}

# Get version
getversion(){
    if [[ -s /etc/redhat-release ]];then
        grep -oE  "[0-9.]+" /etc/redhat-release
    else
        grep -oE  "[0-9.]+" /etc/issue
    fi
}
# CentOS version
centosversion(){
    local code=$1
    local version="`getversion`"
    local main_ver=${version%%.*}
    if [ $main_ver == $code ];then
        return 0
    else
        return 1
    fi
}
# Check OS bit
check_os_bit(){
    ARCHS=""
    if [[ `getconf WORD_BIT` = '32' && `getconf LONG_BIT` = '64' ]] ; then
        Is_64bit='y'
        ARCHS="amd64"
    else
        exit "不兼32位操作系统"
        exit 1
    fi
}
check_centosversion(){
if centosversion 5; then
    echo "安装失败：Not support CentOS 5.x, please change to CentOS 6,7 or Debian or Ubuntu and try again."
    exit 1
fi
}
# Disable selinux
disable_selinux(){
    if [ -s /etc/selinux/config ] && grep 'SELINUX=enforcing' /etc/selinux/config; then
        sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
        setenforce 0
    fi
}
pre_install_packs(){
    local wget_flag=''
    local killall_flag=''
    local netstat_flag=''
    wget --version > /dev/null 2>&1
    wget_flag=$?
    killall -V >/dev/null 2>&1
    killall_flag=$?
    netstat --version >/dev/null 2>&1
    netstat_flag=$?
    if [[ ${wget_flag} -gt 1 ]] || [[ ${killall_flag} -gt 1 ]] || [[ ${netstat_flag} -gt 6 ]];then
        if [ "${OS}" == 'CentOS' ]; then
            yum install -y wget psmisc net-tools
        else
            apt-get -y update && apt-get -y install wget psmisc net-tools
        fi
    fi
}
# Random password
fun_randstr(){
    strNum=$1
    [ -z "${strNum}" ] && strNum="16"
    strRandomPass=""
    strRandomPass=`tr -cd '[:alnum:]' < /dev/urandom | fold -w ${strNum} | head -n1`
    echo ${strRandomPass}
}
fun_get_version(){
    export FRPS_VER=0.20.0
    export FRPS_INIT="http://download.bt.cn/frp/frps.init"
    export github_download_url="http://download.bt.cn/src/frp"
    if [ -z ${FRPS_VER} ] || [ -z ${FRPS_INIT} ]|| [ -z ${github_download_url} ]; then
        exit 1
    fi
}
#

fun_download_file(){
    # download
    program_latest_filename="frp_0.20.0_linux_${ARCHS}.tar.gz"
    program_latest_file_url="${program_download_url}/${program_latest_filename}"
    if [ ! -s ${str_program_dir}/${program_name} ]; then
        rm -fr ${program_latest_filename} frp_${FRPS_VER}_linux_${ARCHS}
        if ! wget --no-check-certificate -q ${program_latest_file_url} -O ${program_latest_filename}; then
            exit 1
        fi
        tar xzf ${program_latest_filename}
        mv frp_${FRPS_VER}_linux_${ARCHS}/frps ${str_program_dir}/${program_name}
        rm -fr ${program_latest_filename} frp_${FRPS_VER}_linux_${ARCHS}
    fi
    chown root:root -R ${str_program_dir}
    if [ -s ${str_program_dir}/${program_name} ]; then
        [ ! -x ${str_program_dir}/${program_name} ] && chmod 755 ${str_program_dir}/${program_name}
    else
        exit 1
    fi
}
function __readINI() {
 INIFILE=$1; SECTION=$2; ITEM=$3
 _readIni=`awk -F '=' '/\['$SECTION'\]/{a=1}a==1&&$1~/'$ITEM'/{print $2;exit}' $INIFILE`
echo ${_readIni}
}
# Check port
fun_check_port(){
    port_flag=""
    strCheckPort=""
    input_port=""
    port_flag="$1"
    strCheckPort="$2"
    if [ ${strCheckPort} -ge 1 ] && [ ${strCheckPort} -le 65535 ]; then
        checkServerPort=`netstat -ntulp | grep "\b:${strCheckPort}\b"`
        if [ -n "${checkServerPort}" ]; then
            netstat -ntulp | grep "\b:${strCheckPort}\b"
            fun_input_${port_flag}_port
        else
            input_port="${strCheckPort}"
        fi
    else
        fun_input_${port_flag}_port
    fi
}

pre_install(){
    disable_selinux
    if [ -s ${str_program_dir}/${program_name} ] && [ -s ${program_init} ]; then
        echo "${program_name} is installed!"
    else
        clear
        fun_get_version
        program_download_url="http://download.bt.cn/src/frp"
        defIP=$(wget -qO- ip.clang.cn | sed -r 's/\r//')
        set_bind_port="15443"
        set_vhost_http_port="18080"
        set_vhost_https_port="18443"
        set_dashboard_port="16443"
        set_dashboard_user=`fun_randstr 8`
        set_dashboard_pwd=`fun_randstr 16`
        set_token=`fun_randstr 32`
        set_max_pool_count="50"
        str_log_level="info"
        set_log_max_days="30"
        str_log_file="/var/log/frps.log"
        str_log_file_flag="enable"
        set_tcp_mux="true"
        set_kcp="true"
        install_program_server
    fi
}
# ====== install server ======
install_program_server(){
    [ ! -d ${str_program_dir} ] && mkdir -p ${str_program_dir}
    cd ${str_program_dir}
    echo "${program_name} install path:$PWD"
    # Config file
    if [ ! -f "${str_program_dir}/${program_config_file}" ]; then
        cat > ${str_program_dir}/${program_config_file}<<-EOF
        # [common] is integral section
        [common]
        # A literal address or host name for IPv6 must be enclosed
        # in square brackets, as in "[::1]:80", "[ipv6-host]:http" or "[ipv6-host%zone]:80"
        bind_addr = 0.0.0.0
        bind_port = ${set_bind_port}
        # udp port used for kcp protocol, it can be same with 'bind_port'
        # if not set, kcp is disabled in frps
        kcp_bind_port = ${set_bind_port}
        # if you want to configure or reload frps by dashboard, dashboard_port must be set
        dashboard_port = ${set_dashboard_port}
        # dashboard assets directory(only for debug mode)
        dashboard_user = ${set_dashboard_user}
        dashboard_pwd = ${set_dashboard_pwd}
        # assets_dir = ./static
        vhost_http_port = ${set_vhost_http_port}
        vhost_https_port = ${set_vhost_https_port}
        # console or real logFile path like ./frps.log
        log_file = ${str_log_file}
        # debug, info, warn, error
        log_level = ${str_log_level}
        log_max_days = ${set_log_max_days}
        # auth token
        token = ${set_token}
        # only allow frpc to bind ports you list, if you set nothing, there won't be any limit
        #allow_ports = 1-65535
        # pool_count in each proxy will change to max_pool_count if they exceed the maximum value
        max_pool_count = ${set_max_pool_count}
        # if tcp stream multiplexing is used, default is true
        tcp_mux = ${set_tcp_mux}
EOF
    fi
    rm -f ${str_program_dir}/${program_name} ${program_init}
    fun_download_file
    if [ ! -s ${program_init} ]; then
        if ! wget --no-check-certificate -q ${github_download_url}"/frps.init" -O ${program_init}; then
            exit 1
        fi
    fi
    [ ! -x ${program_init} ] && chmod +x ${program_init}
    if [ "${OS}" == 'CentOS' ]; then
        chmod +x ${program_init}
        chkconfig --add ${program_name}
    else
        chmod +x ${program_init}
        update-rc.d -f ${program_name} defaults
    fi
    [ -s ${program_init} ] && ln -s ${program_init} /usr/bin/${program_name}
    ${program_init} start
    echo "install successfully"
    exit 0
}
############################### configure ##################################
configure_program_server(){
    if [ -s ${str_program_dir}/${program_config_file} ]; then
        vi ${str_program_dir}/${program_config_file}
    else
        echo "${program_name} configuration file not found!"
        exit 1
    fi
}
############################### uninstall ##################################
uninstall_program_server(){
    if [ -s ${program_init} ] || [ -s ${str_program_dir}/${program_name} ] ; then
            checkos
            ${program_init} stop
            if [ "${OS}" == 'CentOS' ]; then
                chkconfig --del ${program_name}
            else
                update-rc.d -f ${program_name} remove
            fi
            rm -f ${program_init} /var/run/${program_name}.pid /usr/bin/${program_name}
            rm -fr ${str_program_dir}
            echo "${program_name} uninstall success!"
    else
        echo "${program_name} Not install!"
    fi
    exit 0
}

clear
checkos
check_centosversion
check_os_bit
pre_install_packs
action=$1
[  -z $1 ]
case "$action" in
install)
    pre_install 2>&1 | tee /root/${program_name}-install.log
    ;;
config)
    configure_program_server
    ;;
uninstall)
    uninstall_program_server 2>&1 | tee /root/${program_name}-uninstall.log
    ;;
*)
    echo "Usage: `basename $0` {install|uninstall|update|config}"
    RET_VAL=1
    ;;
esac