#!/usr/bin/python
# coding: utf-8
# +------------------------------------------------------------------
# | frp
# +-------------------------------------------------------------------
# | Copyright (c) 2015-2099 宝塔软件(http://bt.cn) All rights reserved.
# +-------------------------------------------------------------------
# | Author: sww
# +-------------------------------------------------------------------
import os
import platform
import subprocess
import sys
import re

BASE_PATH = "/www/server/panel"
os.chdir(BASE_PATH)
sys.path.insert(0, "class/")
import public
import configparser


class frp_main:
    log_path = '/var/log/frps.log'
    config_path = '/usr/local/frps/frps.ini'
    config = {
        'You Server IP': public.get_server_ip(),
        'bind_port': "15443",
        'vhost_http_port': "18080",
        'vhost_https_port': "18443",
        'dashboard_port': "16443",
        'dashboard_user': "admin",
        'dashboard_pwd': "admin16443",
        'token': "admin16443admin16443",
        'max_pool_count': "50",
        'str_log_level': "info",
        'log_max_days': "30",
        'str_log_file': "/var/log/frps.log",
        'str_log_file_flag': "enable",
        'tcp_mux': "true",
        'kcp': "true"}

    def install_frps(self, get=None):
        try:
            if os.path.exists('/www/server/panel/plugin/frp/install_server.pl'):
                return public.returnMsg(False, 'FRPS正在安装中，请稍后再试!')
            public.writeFile('/www/server/panel/plugin/frp/install_server.pl', '')
            public.ExecShell('sh /www/server/panel/plugin/frp/install_server.sh >> /www/server/panel/plugin/frp/install_server.log 2>&1')
            public.ExecShell('rm -f /www/server/panel/plugin/frp/install_server.pl')
        except:
            public.ExecShell('rm -f /www/server/panel/plugin/frp/install_server.pl')
            return public.returnMsg(False, '安装失败，请检查日志![]')

    def get_frps_config(self, get=None):
        if not os.path.exists('/usr/local/frps/frps.ini'):
            for i in ['bind', 'vhost_http', 'vhost_https', 'dashboard']:
                self.config[i] = public.check_firewall_rule(self.config[i + '_port'])
            return False, self.config
        else:
            conf = configparser.ConfigParser(comment_prefixes='#')
            conf.read('/usr/local/frps/frps.ini')
            for key in self.config.keys():
                if conf.has_option('common', key):
                    self.config[key] = conf.get('common', key)
                else:
                    print(key + '不存在')
            for i in ['bind', 'vhost_http', 'vhost_https', 'dashboard']:
                self.config[i] = public.check_firewall_rule(self.config[i + '_port'])
            return True, self.config

    def check_port(self, port):
        '''
        @name 检查端口是否被占用
        @args port:端口号
        @return: 被占用返回True，否则返回False
        '''
        a = public.ExecShell("netstat -nltp|awk '{print $4}'")
        if a[0]:
            if re.search(':' + port + '\n', a[0]):
                return True
            else:
                return False
        else:
            return False

    def install_frps(self, get=None):
        if os.path.exists('/usr/local/frps/frps.ini') and os.path.exists('/etc/init.d/frps') and os.path.exists('/usr/local/frps/frps'):
            return public.returnMsg(False, 'FRPS已经安装了!')
        for k in ['15443', '18080', '18443', '16443']:
            if self.check_port(k):
                return public.returnMsg(False, '{}端口被占用!请修改该端口或者关闭运行在该端口的进程后重试'.format(k))
        data = public.ExecShell('sh /www/server/panel/plugin/frp/install_server.sh install >> /www/server/panel/plugin/frp/install_server.log 2>&1')
        if data[1]:
            return public.returnMsg(False, data[1])
        return public.returnMsg(True, '安装成功!')

    def set_frps_config(self, get):
        try:
            data = get.__dict__
            conf = configparser.ConfigParser(comment_prefixes='#')
            conf.read('/usr/local/frps/frps.ini')
            for k, v in data.items():
                if k in self.config.keys() and k != 'You Server IP':
                    if conf.has_option('common', k):
                        conf.set('common', k, v)
            with open('/usr/local/frps/frps.ini', 'w') as f:
                conf.write(f)
            return public.returnMsg(True, '修改成功!')
        except:
            return public.returnMsg(False, '修改失败!')

    def get_frps_info(self, get=None):
        status = public.ExecShell("/etc/init.d/frps status")
        status = status[0].find("is running") != -1
        config = self.get_frps_config()
        server_addr = 'http://' + public.get_server_ip() + ':' + config[1]['dashboard_port']
        data = {
            'status': status,
            'server_addr': server_addr,
            'install_status': 1 if os.path.exists('/usr/local/frps/frps') else 0,
        }
        return data

    def frps_server_admin(self, get):
        if not hasattr(get, 'status') or not get.status:
            return public.returnMsg(False, '参数错误')
        if get['status'] == 'start':
            config = self.get_frps_config()
            for k, v in config[1].items():
                if k in ['bind_port', 'vhost_http_port', 'vhost_https_port', 'dashboard_port']:
                    if self.check_port(v):
                        return public.returnMsg(False, '{}端口被占用!请修改该端口或者关闭运行在该端口的进程后重试'.format(v))
            res = public.ExecShell("/etc/init.d/frps start")
        elif get['status'] == 'stop':
            res = public.ExecShell("/etc/init.d/frps stop")
        elif get['status'] == 'restart':
            res = public.ExecShell("/etc/init.d/frps restart")
        else:
            return public.returnMsg(False, '参数错误')
        if res[1]:
            return public.returnMsg(False, res[1])
        return public.returnMsg(True, '操作成功')

    def get_win_frpc_config(self, get=None):
        config = self.get_frps_config()
        frpc_config = f"""
[common]
server_addr = {config['You Server IP']} # 服务器IP或者地址
server_port = {config['bind_port']} # 服务器提供的端口号
token = {config['token']} # 服务器提供的token
[web1_{public.GetRandomString(10)}] # 为避免错误,一定需更改为比较特殊的名称,不能和服务器端其他配置重名.或者默认xxxxxx
#补充以下信息！！！！！！！！！！！！！！！！！！
type = http # http协议
local_ip = xxx.xxx.xxx.xxx # 要穿透的内网ip.
local_port = 80 # 要穿透的内网主机端口
custom_domains = xxx.xxx.xxx # 填写你解析到服务器的域名
# 重复可不要
[web2_xxxxxx] # 为避免错误,一定需更改为比较特殊的名称,不能和服务器端其他配置重名.
type = https # https协议
local_ip = xxx.xxx.xxx.xxx  # 要穿透的内网ip
local_port = 443 # 要穿透的内网主机端口
custom_domains = xxx.xxx.xxx # 填写你解析到服务器的域名
"""

        return frpc_config

    def get_frpc_config(self, get=None):
        config = self.get_frps_config()
        frpc_config = f""""""

    def check_os_bit(self):
        try:
            # 尝试使用 platform 模块获取 Python 解释器的架构信息
            machine = platform.machine().lower()
            if "arm" in machine:
                return "arm"
            elif "amd" in machine or "x86_64" in machine:
                return "amd64"
        except Exception as e:
            print(f"Error using platform module: {e}")

        try:
            # 尝试使用命令行获取系统的整体架构信息
            result = subprocess.run(['uname', '-m'], stdout=subprocess.PIPE)
            system_architecture = result.stdout.decode('utf-8').strip().lower()
            if "arm" in system_architecture:
                return "arm"
            elif "amd" in system_architecture or "x86_64" in system_architecture:
                return "amd64"
        except Exception as e:
            print(f"Error using subprocess: {e}")
        return "Error"

    def get_frpc_config(self):
        if os.path.exists('/usr/local/frpc/frpc'):
            return True, public.readFile('/usr/local/frpc/frpc.ini')
        return False, ''

    def install_frpc(self, get=None):
        if os.path.exists('/usr/local/frpc/frpc.ini') and os.path.exists('/etc/init.d/frpc') and os.path.exists('/usr/local/frpc/frpc'):
            return public.returnMsg(False, 'FRPS已经安装了!')
        os_bit = self.check_os_bit()
        if 'Error' in os_bit:
            return public.returnMsg(False, '暂不支持该系统!')
        name = 'frp_0.52.3_linux_{}'.format(os_bit)
        public.ExecShell('wget -O /www/server/panel/plugin/frp/{}.tar.gz http://download.bt.cn/src/frp/{}.tar.gz'.format(name, name))
        public.ExecShell('tar -zxvf /www/server/panel/plugin/frp/{}.tar.gz -C /usr/local/'.format(name))
        public.ExecShell('mv /usr/local/{} /usr/local/frpc'.format(name))
        public.ExecShell('rm -f /www/server/panel/plugin/frp/{}.tar.gz'.format(name))
        public.ExecShell('wget -O /etc/init.d/frpc https://download.bt.cn/src/frp/frpc.init')
        public.ExecShell('chmod +x /etc/init.d/frpc')
        data = """
# [common] 不能缺少
[common]
# 必须附上IPv6的文字地址或主机名
# 在方括号中，如“[：：1]:80”、“[ipv6主机]：http”或“[ipv6主机%区域]：80”
# 对于单个“server_addr”字段，不需要方括号，例如“server_addr=::”。
server_addr = 0.0.0.0
server_port = 7000

# 拨号服务器等待连接完成的最长时间。默认值为10秒.
# dial_server_timeout = 10

# 指定FRPC和frps之间的活动网络连接的keepalive探测间隔。
# 如果为负数，则禁用keep-alive探针.
# dial_server_keepalive = 7200

# 如果你想通过HTTP代理或socks5代理或NTLM代理连接FRPS，你可以在这里或在全局环境变量中设置http_proxy
# 它只在协议为TCP时有效
# http_proxy = http://user:passwd@192.168.1.128:8080
# http_proxy = socks5://user:passwd@192.168.1.128:1080
# http_proxy = ntlm://user:passwd@192.168.1.128:2080

# 日志路径 like ./frpc.log
log_file = ./frpc.log

# 日志等级 trace, debug, info, warn, error
log_level = info
log_max_days = 3

# 当log_file为console时禁用日志颜色，默认为false
disable_log_color = false
# 用于身份验证，应该与您的frps.ini相同
# 指定发送到frps的心跳是否包含认证令牌。默认情况下，该值为false。
authenticate_heartbeats = false

#指定是否在发送到frps的新工作连接中包含认证令牌。默认情况下，该值为false。
authenticate_new_work_conns = false

# 服务器的token
token = xxxxxxxxxxxx

# 此块重复填写
[web1_xxxxxx] # 为避免错误,一定需更改为比较特殊的名称,不能和服务器端其他配置重名.
type = https # https协议
local_ip = xxx.xxx.xxx.xxx  # 要穿透的内网ip
local_port = 443 # 要穿透的内网主机端口
custom_domains = xxx.xxx.xxx # 填写你解析到服务器的域名
"""
        public.writeFile('/usr/local/frpc/frpc.ini', data)
        if 'CentOS' in public.get_os_version():
            public.ExecShell('chkconfig --add frpc')
            public.ExecShell('chkconfig --level 2345 frpc on')
        else:
            public.ExecShell('update-rc.d frpc defaults')
        public.ExecShell('ln -sf /etc/init.d/frpc /usr/bin/frpc')
        return public.returnMsg(True, '安装成功!')

    def frpc_server_admin(self, get):
        if not hasattr(get, 'status') or not get.status:
            return public.returnMsg(False, '参数错误')
        if get['status'] == 'start':
            res = public.ExecShell("/etc/init.d/frpc start")
        elif get['status'] == 'stop':
            res = public.ExecShell("/etc/init.d/frpc stop")
        elif get['status'] == 'restart':
            res = public.ExecShell("/etc/init.d/frpc restart")
        else:
            return public.returnMsg(False, '参数错误')
        if res[1]:
            return public.returnMsg(False, res[1])
        if 'failed' in res[0]:
            return public.returnMsg(False, '启动失败，请检查配置文件')
        return public.returnMsg(True, '启动成功！')

    def get_frpc_info(self, get=None):
        status = public.ExecShell("/etc/init.d/frpc status")
        status = status[0].find("is running") != -1
        data = {'status': status,
                'install_status': 1 if os.path.exists('/usr/local/frpc/frpc') else 0
                }
        return data
